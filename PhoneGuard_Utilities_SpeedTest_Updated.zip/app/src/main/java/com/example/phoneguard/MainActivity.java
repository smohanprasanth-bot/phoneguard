package com.example.phoneguard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout content;
    private TextView phoneScanTab, utilitiesTab;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("PhoneGuard");
        title.setTextColor(Color.WHITE);
        title.setTextSize(29);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(22), dp(26), dp(22), dp(18));
        root.addView(title);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(14), dp(4), dp(14), dp(12));
        phoneScanTab = tab("Phone Scan");
        utilitiesTab = tab("Utilities");
        tabs.addView(phoneScanTab, new LinearLayout.LayoutParams(0, dp(48), 1));
        tabs.addView(utilitiesTab, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(tabs);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(12), dp(20), dp(20));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        phoneScanTab.setOnClickListener(v -> showPhoneScan());
        utilitiesTab.setOnClickListener(v -> openUtilities());
        setContentView(root);
        showPhoneScan();
    }

    private TextView tab(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(15);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setBackground(background("#252525", 24));
        return t;
    }

    private void showPhoneScan() {
        phoneScanTab.setBackground(background("#286B62", 24));
        utilitiesTab.setBackground(background("#252525", 24));
        content.removeAllViews();
        TextView icon = new TextView(this);
        icon.setText("🛡️");
        icon.setTextSize(52);
        icon.setGravity(Gravity.CENTER);
        content.addView(icon, new LinearLayout.LayoutParams(-1, dp(100)));

        TextView heading = new TextView(this);
        heading.setText("Phone Scan");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(22);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        content.addView(heading);

        TextView desc = new TextView(this);
        desc.setText("Open utilities and device tools from PhoneGuard.");
        desc.setTextColor(Color.LTGRAY);
        desc.setTextSize(14);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, dp(8), 0, dp(20));
        content.addView(desc);

        TextView button = actionButton("Open Utilities");
        content.addView(button);
        button.setOnClickListener(v -> openUtilities());
    }

    private void openUtilities() {
        startActivity(new Intent(this, UtilitiesActivity.class));
    }

    private TextView actionButton(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(16);
        t.setTextColor(Color.WHITE);
        t.setGravity(Gravity.CENTER);
        t.setBackground(background("#202020", 28));
        t.setPadding(dp(14), dp(16), dp(14), dp(16));
        return t;
    }

    private GradientDrawable background(String color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(color));
        d.setCornerRadius(dp(radius));
        return d;
    }
    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
