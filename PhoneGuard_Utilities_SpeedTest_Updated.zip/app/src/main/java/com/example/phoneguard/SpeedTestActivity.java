package com.example.phoneguard;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SpeedTestActivity extends Activity {
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("Internet Speed Test");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setPadding(18, 20, 18, 12);
        root.addView(title);

        TextView note = new TextView(this);
        note.setText("FAST.com will measure your internet speed. Results are provided by FAST.com.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        note.setPadding(18, 0, 18, 12);
        root.addView(note);

        WebView web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("https://fast.com/");
        root.addView(web, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    @Override public void onBackPressed() {
        super.onBackPressed();
    }
}
