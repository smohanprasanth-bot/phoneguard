package com.example.phoneguard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.os.BatteryManager;
import android.content.Context;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Toast;

public class UtilitiesActivity extends Activity {
    private GridLayout grid;
    private final String[][] sections = {
        {"Frequently used tools",
            "🔋|Battery", "🌡️|Phone cooling",
            "🆘|Emergency SOS", "🚀|Speed test"},
        {"Security protection",
            "🛡️|Isolation box", "💳|Payment safe", "👾|Scam guard"},
        {"Privacy protection",
            "🔐|App encryption", "🔵|App clone"},
        {"Phone optimization",
            "📶|Network management", "🎮|Ultra Game Mode"},
        {"Space cleanup",
            "🗑️|Junk cleanup", "💬|WhatsApp cleanup",
            "🖼️|Image cleanup", "🎬|Video cleanup",
            "🎙️|Audio cleanup", "📁|Duplicate files"},
        {"Assistance features",
            "📼|Call recordings", "☁️|Data backup", "🔄|EasyShare"}
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this);
        title.setText("Utilities");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(20), dp(24), dp(20), dp(16));
        root.addView(title);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setUseDefaultMargins(false);
        grid.setPadding(dp(14), 0, dp(14), dp(18));
        scroll.addView(grid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        for (String[] section : sections) {
            addHeading(section[0]);
            for (int i = 1; i < section.length; i++) {
                String[] item = section[i].split("\\|", 2);
                addTile(item[0], item[1]);
            }
        }
    }

    private void addHeading(String title) {
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.rgb(185,185,185));
        heading.setTextSize(14);
        heading.setPadding(dp(6), dp(22), 0, dp(8));
        GridLayout.LayoutParams p = new GridLayout.LayoutParams();
        p.width = ViewGroup.LayoutParams.MATCH_PARENT;
        p.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        p.columnSpec = GridLayout.spec(0, 2, GridLayout.FILL, 1f);
        grid.addView(heading, p);
    }

    private void addTile(String icon, String name) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(10), dp(10), dp(6), dp(10));
        tile.setBackground(bg("#202020", 28));

        TextView symbol = new TextView(this);
        symbol.setText(icon);
        symbol.setTextSize(21);
        symbol.setGravity(Gravity.CENTER);
        tile.addView(symbol, new LinearLayout.LayoutParams(dp(32), dp(38)));

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(Color.WHITE);
        label.setTextSize(14);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setPadding(dp(7), 0, 0, 0);
        tile.addView(label, new LinearLayout.LayoutParams(0, -2, 1));

        GridLayout.LayoutParams p = new GridLayout.LayoutParams();
        p.width = 0;
        p.height = dp(70);
        p.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        p.setMargins(dp(3), dp(4), dp(3), dp(4));
        grid.addView(tile, p);
        tile.setOnClickListener(v -> openFeature(name));
    }

    private void openFeature(String name) {
        if (name.equals("Speed test")) {
            startActivity(new Intent(this, SpeedTestActivity.class));
        } else if (name.equals("Battery")) {
            BatteryManager bm = (BatteryManager)getSystemService(Context.BATTERY_SERVICE);
            int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            Toast.makeText(this, "Battery level: " + level + "%", Toast.LENGTH_LONG).show();
        } else if (name.equals("EasyShare")) {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, "Shared from PhoneGuard");
            startActivity(Intent.createChooser(share, "Share using"));
        } else if (name.equals("Data backup")) {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("*/*");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(pick, 100);
        } else {
            Toast.makeText(this, name + " selected. This tool needs its own implementation.", Toast.LENGTH_LONG).show();
        }
    }

    private GradientDrawable bg(String color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.parseColor(color));
        d.setCornerRadius(dp(radius));
        return d;
    }
    private int dp(float v) {
        return (int)(v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
