package com.example.phoneguard

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { ScanScreen() }
            }
        }
    }
}

@Composable
fun ScanScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("pg", Context.MODE_PRIVATE) }

    var key by remember { mutableStateOf(prefs.getString("vt", "") ?: "") }
    var status by remember { mutableStateOf("Tap “Scan apps” to check what's installed.") }
    var busy by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<Finding>>(emptyList()) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("PhoneGuard", style = MaterialTheme.typography.headlineMedium)

        OutlinedTextField(
            value = key,
            onValueChange = { key = it; prefs.edit().putString("vt", it).apply() },
            label = { Text("VirusTotal API key (optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = {
                busy = true
                results = emptyList()
                scope.launch {
                    results = Scanner.scan(ctx, key.trim()) { status = it }
                    val n = results.count { it.level != "LOW" }
                    status = "Done. $n of ${results.size} apps need a look."
                    busy = false
                }
            }) { Text("Scan apps") }

            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }) { Text("Usage access") }
        }

        Text(status, style = MaterialTheme.typography.bodyMedium)

        LazyColumn { items(results) { AppCard(it) } }
    }
}

@Composable
fun AppCard(f: Finding) {
    val ctx = LocalContext.current
    val color = when (f.level) {
        "HIGH" -> Color(0xFFC62828)
        "MEDIUM" -> Color(0xFFEF6C00)
        else -> Color(0xFF2E7D32)
    }
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row {
                Text(f.label, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(f.level, color = color, fontWeight = FontWeight.Bold)
            }
            Text(f.pkg, style = MaterialTheme.typography.bodySmall)
            if (f.reasons.isEmpty()) Text("• No issues found")
            f.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            Row {
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${f.pkg}"))
                    )
                }) { Text("App info") }
                TextButton(onClick = {
                    ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${f.pkg}")))
                }) { Text("Uninstall") }
            }
        }
    }
}
