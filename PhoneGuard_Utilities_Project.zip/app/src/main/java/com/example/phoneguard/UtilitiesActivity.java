package com.example.phoneguard;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.os.BatteryManager;
import android.content.Context;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class UtilitiesActivity extends Activity {
    private GridLayout grid;

    private final String[][] sections = {
        {"Frequently used tools",
            "🔋|Battery", "🌡️|Phone cooling",
            "🆘|Emergency SOS", "🌐|Speed test"},
        {"Security protection",
            "🛡️|Isolation box", "💳|Payment safe", "👾|Scam guard"},
        {"Privacy protection",
            "🔐|App encryption", "🔵|App clone"},
        {"Phone optimization",
            "📶|Network management", "🎮|Ultra Game Mode"},
        {"Space cleanup",
            "🗑️|Junk cleanup", "💬|WhatsApp cleanup",
            "🖼️|Image cleanup", "🎬|Video cleanup",
            "🎙️|Audio cleanup", "📁|Duplicate files"},
        {"Assistance features",
            "📼|Call recordings", "☁️|Data backup", "🔄|EasyShare"}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utilities);
        grid = findViewById(R.id.utilitiesGrid);

        for (String[] section : sections) {
            addHeading(section[0]);
            for (int i = 1; i < section.length; i++) {
                String[] item = section[i].split("\\|", 2);
                addTile(item[0], item[1]);
            }
        }
    }

    private void addHeading(String title) {
        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.rgb(185, 185, 185));
        heading.setTextSize(14);
        heading.setPadding(dp(6), dp(22), 0, dp(8));

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(0, 2, GridLayout.FILL, 1f);
        params.setMargins(0, 0, 0, 0);
        grid.addView(heading, params);
    }

    private void addTile(String icon, String name) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(12), dp(10), dp(8), dp(10));
        tile.setBackground(roundBackground("#202020", 28));
        tile.setClickable(true);
        tile.setFocusable(true);

        TextView symbol = new TextView(this);
        symbol.setText(icon);
        symbol.setTextSize(21);
        symbol.setGravity(Gravity.CENTER);
        tile.addView(symbol, new LinearLayout.LayoutParams(dp(32), dp(38)));

        TextView label = new TextView(this);
        label.setText(name);
        label.setTextColor(Color.WHITE);
        label.setTextSize(14);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setPadding(dp(8), 0, 0, 0);
        tile.addView(label, new LinearLayout.LayoutParams(
            0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = dp(70);
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(dp(3), dp(4), dp(3), dp(4));
        grid.addView(tile, params);

        tile.setOnClickListener(v -> openFeature(name));
    }

    private void openFeature(String name) {
        switch (name) {
            case "Battery":
                BatteryManager bm = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
                int level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
                showMessage("Battery level: " + level + "%");
                break;
            case "Speed test":
                showMessage("Speed test screen is a placeholder. Add a trusted test endpoint to measure speed.");
                break;
            case "Phone cooling":
                showMessage("Phone temperature monitoring is not yet implemented. Android apps cannot directly cool the phone.");
                break;
            case "Emergency SOS":
                showMessage("Set up emergency contacts and permissions before enabling SOS.");
                break;
            case "Payment safe":
                showMessage("Use only official payment apps. This tile is a shortcut placeholder.");
                break;
            case "EasyShare":
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Shared from PhoneGuard");
                startActivity(Intent.createChooser(share, "Share using"));
                break;
            case "Data backup":
                Intent backup = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                backup.setType("*/*");
                backup.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(backup, 100);
                break;
            default:
                showMessage(name + " selected. Feature implementation and required permissions must be added.");
                break;
        }
    }

    private void showMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private GradientDrawable roundBackground(String color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(Color.parseColor(color));
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
