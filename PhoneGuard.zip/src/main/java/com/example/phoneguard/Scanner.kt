package com.example.phoneguard

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.admin.DevicePolicyManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.view.accessibility.AccessibilityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class Finding(
    val label: String,
    val pkg: String,
    val score: Int,
    val reasons: List<String>,
    val apkPath: String
) {
    val level: String
        get() = when {
            score >= 6 -> "HIGH"
            score >= 3 -> "MEDIUM"
            else -> "LOW"
        }
}

object Scanner {
    private val trustedStores = setOf(
        "com.android.vending",   // Google Play
        "com.vivo.appstore",     // vivo V-Appstore
        "com.amazon.venezia"     // Amazon Appstore
    )

    private val riskyPerms = mapOf(
        "READ_SMS" to "reads SMS",
        "RECEIVE_SMS" to "intercepts SMS",
        "SEND_SMS" to "sends SMS",
        "READ_CALL_LOG" to "reads call log",
        "RECORD_AUDIO" to "records audio",
        "ACCESS_BACKGROUND_LOCATION" to "tracks location in background",
        "SYSTEM_ALERT_WINDOW" to "draws over other apps",
        "REQUEST_INSTALL_PACKAGES" to "can install other apps",
        "MANAGE_EXTERNAL_STORAGE" to "full storage access",
        "READ_CONTACTS" to "reads contacts"
    )

    suspend fun scan(
        ctx: Context,
        vtKey: String,
        onProgress: (String) -> Unit
    ): List<Finding> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val now = System.currentTimeMillis()

        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val accessPkgs = am
            .getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .map { it.resolveInfo.serviceInfo.packageName }.toSet()

        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminPkgs = dpm.activeAdmins?.map { it.packageName }?.toSet() ?: emptySet()

        val lastUsed = lastUsedMap(ctx, now)

        @Suppress("DEPRECATION")
        val apps = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS).filter {
            val ai = it.applicationInfo
            ai != null &&
                (ai.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
                it.packageName != ctx.packageName
        }

        val results = mutableListOf<Finding>()
        apps.forEachIndexed { i, p ->
            val ai = p.applicationInfo ?: return@forEachIndexed
            onProgress("Checking app ${i + 1} of ${apps.size}…")

            val reasons = mutableListOf<String>()
            var score = 0

            val store = installer(pm, p.packageName)
            val trusted = store != null && store in trustedStores
            if (!trusted) {
                score += 2
                reasons += "Not installed from a trusted store (sideloaded)"
            }
            if (p.packageName in accessPkgs) {
                score += 3
                reasons += "Has an active accessibility service"
            }
            if (p.packageName in adminPkgs) {
                score += 3
                reasons += "Is an active device administrator"
            }

            val risky = (p.requestedPermissions ?: emptyArray())
                .map { it.substringAfterLast('.') }
                .filter { it in riskyPerms }
                .distinct()
            if (risky.isNotEmpty()) {
                val base = minOf(risky.size, 3)
                score += if (trusted) base / 2 else base
                reasons += "Permissions: " + risky.joinToString { riskyPerms.getValue(it) }
            }

            if (lastUsed != null) {
                val t = lastUsed[p.packageName] ?: 0L
                if (now - t > 90L * 24 * 3600 * 1000) {
                    score += 1
                    reasons += "Not opened in 90+ days (uninstall candidate)"
                }
            }

            results += Finding(
                pm.getApplicationLabel(ai).toString(),
                p.packageName, score, reasons, ai.sourceDir
            )
        }

        // Optional: look up APK hashes on VirusTotal (free key = ~4 lookups/min)
        if (vtKey.isNotBlank()) {
            val targets = results.filter { it.score >= 2 }
                .sortedByDescending { it.score }.take(20)
            targets.forEachIndexed { i, f ->
                onProgress("VirusTotal check ${i + 1} of ${targets.size}… (slow on free keys)")
                val bad = vtLookup(sha256(f.apkPath), vtKey)
                val note = when {
                    bad > 0 -> "VirusTotal: $bad engine(s) flagged it as malicious"
                    bad == 0 -> "VirusTotal: no engine flagged it"
                    bad == -1 -> "VirusTotal: this exact file isn't in its database"
                    else -> "VirusTotal: lookup failed (rate limit or no internet)"
                }
                val extra = when {
                    bad >= 3 -> 6
                    bad > 0 -> 3   // a single hit is often a false positive
                    else -> 0
                }
                val idx = results.indexOfFirst { it.pkg == f.pkg }
                results[idx] = f.copy(score = f.score + extra, reasons = f.reasons + note)
                if (i < targets.lastIndex) delay(16_000)
            }
        }

        results.sortedByDescending { it.score }
    }

    private fun installer(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    // Needs "Usage access" granted; returns null if it isn't.
    private fun lastUsedMap(ctx: Context, now: Long): Map<String, Long>? {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_YEARLY, now - 365L * 24 * 3600 * 1000, now
        )
        if (stats.isNullOrEmpty()) return null
        return stats.groupBy { it.packageName }.mapValues { e -> e.value.maxOf { it.lastTimeUsed } }
    }

    private fun sha256(path: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        File(path).inputStream().use { s ->
            val buf = ByteArray(65536)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // Returns malicious-engine count, -1 = unknown file, -2 = error/limit
    private fun vtLookup(sha: String, key: String): Int {
        val c = URL("https://www.virustotal.com/api/v3/files/$sha")
            .openConnection() as HttpURLConnection
        return try {
            c.setRequestProperty("x-apikey", key)
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            when (c.responseCode) {
                200 -> JSONObject(c.inputStream.bufferedReader().readText())
                    .getJSONObject("data").getJSONObject("attributes")
                    .getJSONObject("last_analysis_stats").getInt("malicious")
                404 -> -1
                else -> -2
            }
        } catch (e: Exception) {
            -2
        } finally {
            c.disconnect()
        }
    }
}
